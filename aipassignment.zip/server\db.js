const Pool=require("pg").Pool;

const pool=new Pool(
    {
        user:"postgresqldbuser@aipassignment-postgresqldbserver",
        password:"Earthree123",
        host:"localhost",
        port:5432,
        database:"aipassignmentdata"
    }
);

module.exports=pool;
